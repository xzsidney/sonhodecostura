---
name: Atelier Moderno
colors:
  surface: '#f9f9f8'
  surface-dim: '#d9dad9'
  surface-bright: '#f9f9f8'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f3f4f3'
  surface-container: '#edeeed'
  surface-container-high: '#e7e8e7'
  surface-container-highest: '#e1e3e2'
  on-surface: '#191c1c'
  on-surface-variant: '#424842'
  inverse-surface: '#2e3131'
  inverse-on-surface: '#f0f1f0'
  outline: '#727972'
  outline-variant: '#c2c8c0'
  surface-tint: '#44664e'
  primary: '#44664e'
  on-primary: '#ffffff'
  primary-container: '#8fb397'
  on-primary-container: '#254630'
  inverse-primary: '#abcfb2'
  secondary: '#82524e'
  on-secondary: '#ffffff'
  secondary-container: '#febfba'
  on-secondary-container: '#7a4b48'
  tertiary: '#4e6171'
  on-tertiary: '#ffffff'
  tertiary-container: '#99adbf'
  on-tertiary-container: '#2e4150'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#c6eccd'
  primary-fixed-dim: '#abcfb2'
  on-primary-fixed: '#00210f'
  on-primary-fixed-variant: '#2d4e37'
  secondary-fixed: '#ffdad7'
  secondary-fixed-dim: '#f5b7b2'
  on-secondary-fixed: '#33110f'
  on-secondary-fixed-variant: '#673b37'
  tertiary-fixed: '#d1e5f8'
  tertiary-fixed-dim: '#b5c9db'
  on-tertiary-fixed: '#091d2b'
  on-tertiary-fixed-variant: '#364958'
  background: '#f9f9f8'
  on-background: '#191c1c'
  surface-variant: '#e1e3e2'
typography:
  display-accent:
    fontFamily: Playfair Display
    fontSize: 48px
    fontWeight: '400'
    lineHeight: '1.2'
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Manrope
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
  headline-lg-mobile:
    fontFamily: Manrope
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
  body-md:
    fontFamily: Manrope
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-sm:
    fontFamily: Manrope
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 8px
  container-max: 1200px
  gutter: 24px
  margin-desktop: 64px
  margin-mobile: 20px
---

## Brand & Style

This design system embodies the "Handmade Professional" aesthetic. It balances the warmth of a local craft studio with the precision of a high-end atelier. The UI serves as a quiet, sophisticated gallery for colorful textile patterns and handmade goods, prioritizing clarity and breathability.

The visual style is **Minimalist-Tactile**. By combining high-density whitespace with subtle physical metaphors—like soft shadows and organic corner radii—the interface feels approachable and tangible. It avoids the coldness of corporate minimalism by embracing a palette and shape language that mirrors the softness of fabric and thread.

## Colors

The color palette is derived directly from the brand’s artisanal roots:
- **Sage Green (Primary):** Used for primary actions, navigation backgrounds, and success states. It represents growth and the organic nature of craft.
- **Soft Terracotta/Pink (Secondary):** Used for accent elements, promotional highlights, and CTA buttons to provide a warm, inviting contrast.
- **Charcoal Grey (Tertiary):** Used for primary typography and iconography to ensure high legibility without the harshness of pure black.
- **Off-White/Linen (Neutral):** A slightly warm neutral used for page backgrounds and container surfaces to reduce eye strain and feel more like natural fabric.

## Typography

The typographic system utilizes a "High-Low" pairing strategy:
- **Display Accent:** Use *Playfair Display* (Italic) for short brand moments, section headers, and poetic callouts. This mimics the elegant script of the logo and adds a human touch.
- **UI Elements:** Use *Manrope* for all functional components, body text, and labels. Its geometric yet friendly terminals ensure readability even on small mobile screens.

Keep line lengths for body text between 45-75 characters to maintain a comfortable reading rhythm, reflecting the "slow craft" philosophy of the brand.

## Layout & Spacing

The layout follows a **Fluid Grid** model with generous inner padding to evoke an "Airy" feel. 
- **Desktop:** A 12-column grid with wide margins allows the product imagery to breathe. 
- **Mobile:** A single-column reflow with a focus on verticality and large touch targets (minimum 44px).

Spacing follows a strict 8px base unit. Use larger "Oxygen" gaps (64px+) between major sections to prevent the interface from feeling cluttered, allowing the user to focus on one craft category at a time.

## Elevation & Depth

To achieve a tactile, artisanal feel, this design system uses **Ambient Shadows** and **Tonal Layers** rather than flat borders.

- **Level 1 (Base):** Off-white background (#F8F9F8).
- **Level 2 (Cards/Containers):** Pure white (#FFFFFF) with a very soft, diffused shadow (10% opacity Charcoal Grey, 20px blur, 4px offset).
- **Level 3 (Floating Elements):** Increased shadow spread to indicate interactivity (e.g., a "hover" state on a product card).

Avoid using inner shadows or heavy borders, which can make the UI feel "heavy" or "industrial." Depth should feel like layers of paper or fabric stacked on a work table.

## Shapes

The shape language is consistently **Rounded**. 
- Corners are set to `0.5rem` (8px) for standard components like input fields and buttons.
- Large cards or hero images use `1rem` (16px) to soften the visual impact.
- Avoid sharp 90-degree angles, as they conflict with the "handmade" narrative. Circles may be used for category icons or profile avatars to reinforce the organic theme.

## Components

- **Buttons:** Primary buttons use the Sage Green background with white text. Secondary buttons use a Charcoal Grey ghost style (outline only). All buttons feature `rounded-lg` corners and a subtle lift on hover.
- **Input Fields:** Use a light grey background with a bottom-only border or a very soft full-border. Labels should always be visible above the field in `label-sm`.
- **Cards:** Product cards are the centerpiece. Use a white background, no visible border, and the standard shadow. Text should be left-aligned with the primary price in a bold Manrope weight.
- **Chips:** Used for fabric types (e.g., "100% Cotton"). These should have pill-shaped roundedness and use the Soft Terracotta color at 10% opacity for the background to keep them subtle.
- **Interactive Progress:** For custom orders, use a "Stitch-line" stepper—a dashed line connecting points to visualize the crafting process.